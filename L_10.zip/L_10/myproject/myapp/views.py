from django.shortcuts import render, redirect, get_object_or_404
from .models import Person

def index(request):
    people = Person.objects.all()
    return render(request, 'index.html', {'people': people})

def form(request):
    if request.method == 'POST':
        name = request.POST['name']
        age = request.POST['age']
        Person.objects.create(name=name, age=age)
        return redirect('/')
    return render(request, 'form.html')

def edit(request, id):
    person = get_object_or_404(Person, id=id)
    if request.method == 'POST':
        person.name = request.POST['name']
        person.age = request.POST['age']
        person.save()
        return redirect('/')
    return render(request, 'edit.html', {'person': person})

def delete(request, id):
    person = get_object_or_404(Person, id=id)
    person.delete()
    return redirect('/')