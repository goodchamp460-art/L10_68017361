from django.contrib import admin
from .models import Person

class PersonAdmin(admin.ModelAdmin):
    list_display = ('name', 'age')  # คอลัมน์ที่จะแสดงในตาราง

admin.site.register(Person, PersonAdmin)